create
    definer = root@localhost procedure add_student(IN student_name varchar(255), IN student_age int)
BEGIN
    INSERT INTO students (name, age) VALUES (student_name, student_age);
END;

