create
    definer = root@localhost procedure ListEmployees()
BEGIN
    DECLARE done INT DEFAULT 0;
    DECLARE emp_name VARCHAR(255);
    DECLARE emp_position VARCHAR(255);
    DECLARE cur CURSOR FOR SELECT name, position FROM employees;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

    OPEN cur;

    read_loop: LOOP
        FETCH cur INTO emp_name, emp_position;
        IF done THEN
            LEAVE read_loop;
        END IF;
        -- 这里，您可以对每个员工的数据进行操作。例如，打印他们的名字和职位:
        SELECT emp_name, emp_position;
    END LOOP;

    CLOSE cur;
END;

