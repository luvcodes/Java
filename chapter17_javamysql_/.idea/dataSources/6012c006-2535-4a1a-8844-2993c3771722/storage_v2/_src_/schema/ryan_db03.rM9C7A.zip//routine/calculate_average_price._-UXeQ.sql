create
    definer = root@localhost procedure calculate_average_price(OUT avg_price decimal(10, 2))
BEGIN
    DECLARE total_price DECIMAL(10, 2);
    DECLARE total_products INT;

    SELECT SUM(price) INTO total_price FROM products;
    SELECT COUNT(id) INTO total_products FROM products;

    SET avg_price = total_price / total_products;
END;

