create
    definer = root@localhost procedure GetStudentAge()
BEGIN
    DECLARE student_age INT;  -- 声明变量

    SELECT age
    INTO student_age  -- 将查询结果赋值给变量
    FROM students
    WHERE name = 'John Doe';

    -- 这里可以使用变量student_age进行其他操作
    SELECT student_age;  -- 例如，我们可以选择它来查看值
END;

