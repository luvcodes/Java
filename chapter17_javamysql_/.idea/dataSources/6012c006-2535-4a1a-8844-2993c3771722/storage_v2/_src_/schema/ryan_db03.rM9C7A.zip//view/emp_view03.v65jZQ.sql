create definer = root@localhost view emp_view03 as
select `ryan_db03`.`emp`.`empno`      AS `empno`,
       `ryan_db03`.`emp`.`ename`      AS `ename`,
       `ryan_db03`.`dept`.`dname`     AS `dname`,
       `ryan_db03`.`salgrade`.`grade` AS `grade`
from `ryan_db03`.`emp`
         join `ryan_db03`.`dept`
         join `ryan_db03`.`salgrade`
where ((`ryan_db03`.`emp`.`deptno` = `ryan_db03`.`dept`.`deptno`) and
       (`ryan_db03`.`emp`.`sal` between `ryan_db03`.`salgrade`.`losal` and `ryan_db03`.`salgrade`.`hisal`));

